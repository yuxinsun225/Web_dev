const mongoose = require('mongoose');
mongoose.connect('mongodb://localhost:27017/family')
    .then(() => {
        console.log('Connection Open!!');
    })
    .catch((err) => {
        console.log("connection failed!!");
        console.log(err);
    })

// main().catch(err => {
//     console.log("Connection Failed!!");
//     console.log(err);
// });

// async function main() {
//     await mongoose.connect('mongodb://localhost:27017/family');
console.log('Connection open!!!');
const petSchema = new mongoose.Schema({
    name: String,
    age: Number,
    likeCuddle: Boolean,
    favouriteFood: String
});
const Pet = mongoose.model('Pet', petSchema);
    // const dundun = new Pet({
    //     name: "Dundun",
    //     age: 4.5,
    //     likeCuddle: false,
    //     favouriteFood: "basil"
    // })
    // dundun.save();

    // Pet.insertMany([
    //     {
    //         name: "Dundun",
    //         age: 4.5,
    //         likeCuddle: false,
    //         favouriteFood: "basil"

    //     }, {
    //         name: "Susu",
    //         age: 4.5,
    //         likeCuddle: false,
    //         favouriteFood: "basil"
    //     }, {
    //         name: "Tuomomo",
    //         age: 34,
    //         likeCuddle: true,
    //         favouriteFood: "whatever Yuxin cooks"
    //     }, {
    //         name: "Nemo",
    //         age: 0.3,
    //         likeCuddle: true,
    //         favouriteFood: "meat"
    //     }])
    //     .then(data => {
    //         console.log("it worked!!!!");
    //         console.log(data);
    //     })
// }