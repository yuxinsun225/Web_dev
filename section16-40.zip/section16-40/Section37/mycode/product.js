const mongoose = require("mongoose");
mongoose
  .connect("mongodb://localhost:27017/shopApp")
  .then(() => {
    console.log("Connection Open!!");
  })
  .catch((err) => {
    console.log("connection failed!!");
    console.log(err);
  });

const productSchema = new mongoose.Schema({
  name: {
    type: String,
    maxlength: 20,
    required: true,
  },
  price: {
    type: Number,
    min: [0, "Price needs to be greater than 0"],
    required: true,
  },
  isOnSale: {
    type: Boolean,
    default: false,
  },
  categories: {
    type: [String],
  },
  qty: {
    online: {
      type: Number,
      default: 0,
    },
    inStore: {
      type: Number,
      default: 0,
    },
  },
});

productSchema.methods.greet = function () {
  console.log(`Helllllo! My name is ${this.name}`);
};

productSchema.methods.toggleSale = function () {
  this.isOnSale = !this.isOnSale;
  return this.save();
};

productSchema.methods.removeCategory = function (newCat) {
  this.categories.pop(newCat);
  return this.save();
};

productSchema.statics.fireSale = function () {
  return this.updateMany({}, { onSale: true, price: 0 });
};

const Product = mongoose.model("Product", productSchema);

const findProduct = async () => {
  const foundProduct = await Product.findOne({ name: "Pump" });
  await foundProduct.toggleSale();
  //   await foundProduct.removeCategory("Outdoors");
  console.log(foundProduct);
  Product.fireSale().then((result) => console.log(result));
};

findProduct();

// const bike = new Product({
//   name: "Pump",
//   price: 19.95,
//   categories: ["Convenient", "Bike"],
// });
// bike
//   .save()
//   .then((data) => {
//     console.log("It worked!!");
//     console.log(data);
//   })
//   .catch((e) => {
//     console.log("Oh nooooo!");
//     console.log(e);
//   });

// Product.findOneAndRemove({ name: "Helmet" }).then((data) => {
//   console.log(data);
// });

// Product.findOneAndUpdate(
//   { name: "Pump" },
//   { price: 19.9 },
//   { new: true, runValidators: true }
// )
//   .then((data) => {
//     console.log(data);
//   })
//   .catch((err) => {
//     console.log(ReferenceError);
//   });
