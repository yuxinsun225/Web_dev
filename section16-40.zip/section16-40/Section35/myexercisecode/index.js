const express = require('express');
const { v4: uuid } = require('uuid');
const methodOverride = require('method-override');
const app = express();
const path = require('path');
const port = 3000;

app.use(express.urlencoded({ extended: true }));
app.use(methodOverride('_method'));

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, '/views'));

let tweets = [
    {
        id: uuid(),
        name: 'Tuomomo',
        tweet: 'Moi! Mina olen Suomilainen!'
    },
    {
        id: uuid(),
        name: 'Badundun',
        tweet: 'Hello! I will eat you alive!'
    },
    {
        id: uuid(),
        name: 'Pususu',
        tweet: 'Hello! Badundun is my boss!'
    },
    {
        id: uuid(),
        name: 'Yuxinxin',
        tweet: 'Hello! I am the queen of our family! Everyone listens to me!'
    }
]



app.get('/tweets', (req, res) => {
    res.render('tweets/index', { tweets });
})

app.get('/tweets/new', (req, res) => {
    res.render('tweets/new');
})

app.post('/tweets', (req, res) => {
    const { name, tweet } = req.body;
    tweets.push({ id: uuid(), name, tweet });
    res.redirect('/tweets')
})

app.get('/tweets/:id', (req, res) => {
    const { id } = req.params;
    const tweet = tweets.find(el => el.id === id);
    res.render('tweets/detail', { tweet });
})

app.get('/tweets/:id/edit', (req, res) => {
    const { id } = req.params;
    const tweet = tweets.find(el => el.id === id);
    res.render('tweets/edit', { tweet });
})

app.patch('/tweets/:id/', (req, res) => {
    const { id } = req.params;
    const oldTweet = tweets.find(el => el.id === id);
    const { tweet: newTweet } = req.body;
    oldTweet.tweet = newTweet;
    res.redirect('/tweets');
})

app.delete('/tweets/:id', (req, res) => {
    const { id } = req.params;
    tweets = tweets.filter(el => el.id !== id);
    console.log(tweets);
    res.redirect('/tweets');
})


app.listen(port, () => console.log('Listening on Port 3000....'));