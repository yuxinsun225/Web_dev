// fetch('https://api.cryptonator.com/api/ticker/btc-usd')
//     .then(res => {
//         console.log("RESPONSE, WAITING TO PARSE...", res)
//         return res.json()
//     })
//     .then(data => {
//         console.log("DATA PARSED...")
//         console.log(data.ticker.price)
//     })
//     .catch(e => {
//         console.log("OH NO! ERROR!", e)
//     })


// const fetchBitcoinPrice = async () => {
//     try {
//         const res = await fetch('https://api.cryptonator.com/api/ticker/btc-usd');
//         const data = await res.json();
//         console.log(data.ticker.price)
//     } catch (e) {
//         console.log("SOMETHING WENT WRONG!!!", e)
//     }
// }

// fetch('https://api.tvmaze.com/singlesearch/shows?q=girls&embed=episodes')
// .then (res => {
//     console.log("response, waiting to parse..",res);
//     return res.json();
// })
// .then(data=> {
//     console.log("Data parsed...");
//     console.log(data.averageRuntime);
// })
// .catch (e=> {
//     console.log("oh nooooo",e);
// })

// const fetchPrice = async () => {
//     try {
//         const res = await fetch('https://api.tvmaze.com/singlesearch/shows?q=girls&embed=episodes');  // with await, res is the result of fetch, without await, res is the promise;
//         const data = await res.json();
//         console.log(data.genres);
//     }
//     catch (e) {
//         console.log(e);
//     }
// }

// fetchPrice();

// axios.get('https://api.tvmaze.com/singlesearch/shows?q=girls&embed=episodes')
// .then(res => {
//     console.log(res.data.averageRuntime);
// })
// .catch(e => {
//     console.log(e);
// })

// const getInfo = async() => {
//     try {
//         let res = await axios.get('https://api.tvmaze.com/singlesearch/shows?q=girls&embed=episodes');
//         console.log(res.data.averageRuntime);
//     }
//     catch (e) {
//         console.log(e);
//     }
// }

const btn = document.querySelector('button');
const list = document.querySelector('ul');

const getDadJoke = async () => {
    try {
    const config = { headers: { Accept: 'application/json'}}
    const jokeRes=  await axios.get("https://icanhazdadjoke.com/", config);
    return jokeRes.data.joke;
    } 
    catch (e) {
        console.log(e);
        return "No jokes available, sorry!"
    }
}


const addNewJoke = async() => {
    const newJoke = await getDadJoke();
    const joke = document.createElement('li');
    joke.append(newJoke);
    list.append(joke);
}

btn.addEventListener('click', addNewJoke);
