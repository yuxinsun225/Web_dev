// const form = document.querySelector('#searchForm');
// form.addEventListener('submit', async function (e) {
//     e.preventDefault();
//     const searchTerm = form.elements.query.value;
//     const config = { params: { q: searchTerm } }
//     const res = await axios.get(`http://api.tvmaze.com/search/shows`, config);
//     makeImages(res.data)
//     form.elements.query.value = '';
// })

// const makeImages = (shows) => {
//     for (let result of shows) {
//         if (result.show.image) {
//             const img = document.createElement('IMG');
//             img.src = result.show.image.medium;
//             document.body.append(img)
//         }
//     }
// }

const form = document.querySelector('form');
const doSearch = async () => {
    const TVName = form.elements.TVSearch.value;
    const config = {params: {q: TVName}}
    const res = await axios.get("https://api.tvmaze.com/search/shows?", config);
    createImages(res.data);
    form.elements.TVSearch.value='';


}

const createImages = (shows) => {
    for (TV of shows) {
        if (TV.show.image) {
            const img = document.createElement('img');
            img.src = TV.show.image.medium;
            document.body.append(img);
        }
    }
}


form.addEventListener('submit', (e) => {
    e.preventDefault();
    doSearch();
})