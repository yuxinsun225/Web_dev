//String.prototype is a "template object" for every single string.
//We could go crazy and add our own method called yell...
// String.prototype.yell = function() {
// 	return `OMG!!! ${this.toUpperCase()}!!!!! AGHGHGHG!`;
// };

// 'bees'.yell(); //"OMG!!! BEES!!!!! AGHGHGHG!"

// //We can overwrite an existing Array method like pop (not a good idea):
// Array.prototype.pop = function() {
// 	return 'SORRY I WANT THAT ELEMENT, I WILL NEVER POP IT OFF!';
// };
// const nums = [ 6, 7, 8, 9 ];
// nums.pop(); // "SORRY I WANT THAT ELEMENT, I WILL NEVER POP IT OFF!"

const navColor = new Color('carrot', [230,126,34]);
const logoColor = new Color('emerald', [46,204,113]);