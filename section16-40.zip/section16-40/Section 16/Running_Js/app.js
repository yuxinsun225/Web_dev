// let rating=Math.random();
// console.log(`Your n is ${rating}`);
// if (rating<0.5) {
//     console.log("it is smaller than 0.5");
// }

// else {
//     console.log("it is greater than 0.5");  
// }

// const dayOfWeek= 'Saturday';
// if (dayOfWeek ==='Monday') {
//     console.log("I hate Mondays!!!!");
// } else if (dayOfWeek === 'Saturday') {
//     console.log("Yay I love Saturdays!!");
// }

// let age = parseInt(prompt("Please enter your age:"));
// while (isNaN(age)) {
//     age = parseInt(prompt("Please enter a valid age:"));
// } 
// if (age<5) {
//     console.log("You are a child. You get in free.");
// } else if (age<10) {
//     console.log("You can pay half price.");
// } else if (age<65) {
//     console.log("You are adult. You pay full price.");
// } else {
//     console.log("You are senior. You are not allowed in.");
// }

// let age = parseInt(prompt("please enter your age"));
// if (0<age && age <5) {
//     console.log("free");
// } else if (age<10 || 110 > age && age > 65) {
//     console.log("$10");
// } else if (10<=age && age <=65) {
//     console.log("full price");
// } else {
//     console.log("age not valid");
// }

// const person = {
//     firstName: 'Tuomo',
//     lastName: 'Tanttu',
//     birthDay: '11 Aug 1987',
// }

// const ns = [[1,3,5],[2,4,6],[3,5,7]];
// for (let i=0; i<3; i++) {
//     for (let j=0; j<3; j++) {
//         console.log(`i is ${i}, j is ${j}, n is ${ns[i][j]}`);
//     }
// }

// let maxNumber = parseInt(prompt("Please enter a max number:"));
// let count = 0;
// let n = 0;

// while (maxNumber !== 'q') {
//     if (!parseInt(maxNumber)) {
//         maxNumber = prompt("Please enter a max NUMBER:");
//     } else {
//         maxNumber = parseInt(maxNumber);
//         break;
//     }
// }
// if (maxNumber === 'q') {
//     n = 'q';
// } else {
//     randomNumber = Math.round(Math.random() * maxNumber);
//     console.log(`the random number is ${randomNumber}`);
//     n = prompt("Please guess number");
// }
// while (n !== 'q') {
//     if (!parseInt(n)) {
//         n = prompt("Please guess a NUMBER!:");
//     } else {
//         n = parseInt(n);
//         if (n < randomNumber) {
//             n = prompt("Please guess a bigger nnumber:");
//         } else if (n > randomNumber) {
//             n = prompt("Please guess a smaller number:");
//         } else if (n === randomNumber) {
//             console.log(`You tried ${count} times`);
//             break;
//         }
//         count++;
//         console.log(count);
//     }
// }
// if (n === 'q') {
//     console.log("You chose to quit game.");
// }

// let todoList = [];
// let i = 0;
// let cmd = prompt("Please enter a command: ");
// let todoItem = '';
// while (cmd !== 'quit') {
//     if (cmd === 'new') {
//         todoItem = prompt("Please enter your todo item:");
//         todoList.push(todoItem);
//         cmd = prompt("Please enter a command: ");
//     } else if (cmd === 'list') {
//         console.log('*************');
//         for (i = 0; i < todoList.length; i++) {
//             console.log(`${i}: ${todoList[i]}`);
//         }
//         console.log('*************');
//         cmd = prompt("Please enter a command: ");
//     } else if (cmd === 'delete') {
//         i = parseInt(prompt("Please enter the index number of the item you want to delete:"));
//         while (!i || i < 0 || i > todoList.length) {
//             if (!i) {
//                 i = parseInt(prompt("That's not a number. Please enter the index number of the item you want to delete:"));
//             } else {
//                 i = parseInt(prompt(`That's not a valid index. Must be >= 0 and < ${todoList.length}. Please enter again:`));
//             }
//         }
//         todoItem = todoList.splice(i, 1);
//         console.log(`You have deleted ${todoItem} from the list.`);
//         cmd = prompt("Please enter a command: ");
//     } else {
//         cmd = prompt("That's not a valid command. Please enter a command: ");
//     }
// }

// if (cmd === 'quit') {
//     console.log("You chose to quit.");
// }

// function repeat (word, times) {
//     let string = '';
//     for (let i=0;i<times;i++) {
//         string = string+word;
//     } 
//     console.log(`${string}`);
// }

// function makeBtwFunc(min,max) {
//     return function(num) {
//         return num>=min && num<=max;
//     }
// }

// const func = makeBtwFunc(2,80);

// const myMath = {
//     pi: 3.1415926,
//     square: function(num) {
//         return num*num;
//     },
//     cube(num) {
//         return num**3;
//     }
// }

// const hen = {
//     name: 'Helen',
//     eggCount: 0,
//     layAnEgg() {
//         this.eggCount++;
//         return 'EGG';
//     }
// }

const movies = [
    {
        title: 'Amadeus',
        score:89
    },
    {
        title: 'Stand By Me',
        score:85
    },
    { 
        title: 'Alien',
        score: 90
    },
    {
        title: 'Parasite',
        score: 98
    }
]

const bestMovie = movies.reduce((better, movie) => {
    if (movie.score>better.score) {
        return movie;
    } else {
        return better;
    }
}).title

// const titles = movies.map((movie) => movie.title.toUpperCase());

// const titles = movies.map(function (movie) {
//     return movie.title.toUpperCase();
// })
// movies.forEach(function(movieScore) {
//     console.log(`${movieScore.title} - ${movieScore.score}/100`);
// })

// const numbers = [];
// for (let i = 1; i<=20; i++) {
//     numbers.push(i);
// }

// const mul4 = numbers.filter((n)=> n%4===0);


// let newnum = numbers.map(function(num) {
//     return num * 2;
// })

// const square = (x) => {
//     console.log(x);
// }

// console.log("Hello");
// setTimeout(()=>{console.log("Hello")}, 3000);
// console.log("after Hello");

// let id = setInterval(()=>{console.log(Math.random())},2000);

// const usernames = ["asdfa3234","asdfasfdjl23","329234", "asdf","asdflji2er0r"];

// const validUserNames = (usernames) => {
//     const newarray = usernames.filter(n => n.length<=10);
//     return newarray;
// }

// const prices = [9.99, 1.50, 2.50, 6.69, 49.99, 30.49];

// const [carrot, apple, kiwi,...everythingElse] = prices;
// const totalPrices = prices.reduce((total, el) => {
//     console.log(total);
//     return total+el;
// })

// function greeting(greet="Hey there", name) {
//     console.log(`${greet}, ${name}`);
// }

// const guineaPig = {
//     number: 2,
//     first: ["Badun", "Pusu"],
//     lastName:["Sun","Tanttu"]
// }

// const cat = {
//     number: 1,
//     firstName: "Naonao",
//     lastName: "Sun"
// }

// function sum(...num) {
//     return num.reduce((total, el) => total+el);
// }



