module.exports = {
    name: 'blue',
    color: 'grey'
}