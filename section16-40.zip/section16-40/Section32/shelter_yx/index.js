const sadie = require('./sadie');
const harry = require('./harry');
const lexi = require('./lexi');

const animals = [sadie, harry, lexi];

module.exports = animals;
