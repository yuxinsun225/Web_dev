module.exports = {
    name: 'sadie',
    age: '8',
    color: 'orange'
}