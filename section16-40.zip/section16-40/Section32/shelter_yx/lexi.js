module.exports = {
    name: 'lexi',
    age: '3',
    color: 'tabby'
}