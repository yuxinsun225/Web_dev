module.exports = {
    name: 'harry',
    age: '3',
    color: 'grey'
}