import { franc, francAll } from 'franc';
import langs from 'langs';
import colors from 'colors';
const input = process.argv.slice(2).join(' ');
try {
    const code = franc(input);
    console.log(langs.where("3", code).name.green);
} catch (e) {
    console.log('Something went wrong. Please try again!'.red)
}