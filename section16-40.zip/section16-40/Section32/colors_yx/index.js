const colors = require('colors');
const jokes = require('give-me-a-joke');
const cowsay = require('cowsay');
jokes.getRandomDadJoke((joke) => {
    console.log(cowsay.say({
        text: joke,
    }).rainbow)
})
