// const math = require('./Math_Yuxin');
// console.log(math.square(9));

const animals = require('./shelter_yx')
console.log(animals);