

// const tweetForm = document.querySelector('#tweetForm');
// const tweetsContainer = document.querySelector('#tweets');
// tweetForm.addEventListener('submit', function (e) {
//     e.preventDefault();

//     // const usernameInput = document.querySelectorAll('input')[0];
//     // const tweetInput = document.querySelectorAll('input')[1];
//     const usernameInput = tweetForm.elements.username;
//     const tweetInput = tweetForm.elements.tweet;
//     addTweet(usernameInput.value, tweetInput.value)
//     usernameInput.value = '';
//     tweetInput.value = '';
// });

// const addTweet = (username, tweet) => {
//     const newTweet = document.createElement('li');
//     const bTag = document.createElement('b');
//     bTag.append(username)
//     newTweet.append(bTag);
//     newTweet.append(`- ${tweet}`)
//     tweetsContainer.append(newTweet);
// }
const lis = document.querySelectorAll('li');
for( let li of lis) {
    li.addEventListener('click', ()=> {
        li.remove();
    })
}
const form = document.querySelector('#tweetForm');
const post = document.querySelector('#tweets');

form.addEventListener('submit',function(e) {
    const userName = this.elements.username.value;  
    const tweet = this.elements.tweet.value;
    e.preventDefault();
    addTweet(userName, tweet);
    this.elements.username.value = '';
    this.elements.tweet.value = '';
})

function addTweet (userName,tweet) {
    const newTweetInfo = document.createElement('li');
    const btag = document.createElement('b');
    btag.append(userName);
    newTweetInfo.append(btag, '-', tweet);
    post.append(newTweetInfo);
}

// const username = document.querySelector('input');

