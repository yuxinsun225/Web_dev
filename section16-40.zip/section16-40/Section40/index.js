const express = require("express");
const app = express();
const morgan = require("morgan");

app.use(morgan("tiny"));
// app.use((req, res, next) => {
//   req.requestTime = Date.now();
//   console.log(req.method, req.path);
//   next();
// });

// app.use("/cats", (req, res, next) => {
//   console.log("i love cats!!!");
//   next();
// });

const verify = (req, res, next) => {
  const { password } = req.query;
  if (password === "chickennugget") {
    next();
  }
  res.send("Your password is wrong!!!");
};

app.listen(3000, () => {
  console.log("Listening on port 3000...");
});

app.get("/cats", (req, res) => {
  res.send("Meooooow");
});

app.get("/secret", verify, (req, res) => {
  res.send(
    "Sometimes I wear headphones in public so that I don't need to talk to anyone"
  );
});

app.get("/", (req, res) => {
  res.send("Home Page!");
});
