// ===============
// YIKES!!!!!!!!!!!
// ===============
// setTimeout(() => {
//     document.body.style.backgroundColor = 'red';
//     setTimeout(() => {
//         document.body.style.backgroundColor = 'orange';
//         setTimeout(() => {
//             document.body.style.backgroundColor = 'yellow';
//             setTimeout(() => {
//                 document.body.style.backgroundColor = 'green';
//                 setTimeout(() => {
//                     document.body.style.backgroundColor = 'blue';
//                 }, 1000)
//             }, 1000)
//         }, 1000)
//     }, 1000)
// }, 1000)


// const delayedColorChange = (newColor, delay, doNext) => {
//     setTimeout(() => {
//         document.body.style.backgroundColor = newColor;
//         doNext && doNext();
//     }, delay)
// }

// // STILL A LOT OF NESTING!!!
// delayedColorChange('red', 1000, () => {
//     delayedColorChange('orange', 1000, () => {
//         delayedColorChange('yellow', 1000, () => {
//             delayedColorChange('green', 1000, () => {
//                 delayedColorChange('blue', 1000, () => {

//                 })
//             })
//         })
//     })
// });


// searchMoviesAPI('amadeus', () => {
//     saveToMyDB(movies, () => {
//         //if it works, run this:
//     }, () => {
//         //if it doesn't work, run this:
//     })
// }, () => {
//     //if API is down, or request failed
// })


// setTimeout(() => {
//     document.body.style.backgroundColor = 'red';
//     setTimeout(() => {
//         document.body.style.backgroundColor = 'orange';
//         setTimeout(() => {
//             document.body.style.backgroundColor = 'yellow';
//             setTimeout(() => {
//                 document.body.style.backgroundColor = 'green';
//                 setTimeout(() => {
//                     document.body.style.backgroundColor = 'cyan';
//                     setTimeout(() => {
//                         document.body.style.backgroundColor = 'blue';
//                         setTimeout(() => {
//                             document.body.style.backgroundColor = 'purple';
//                         }, 1000)
//                     }, 1000)
//                 }, 1000)
//             }, 1000)
//         }, 1000)
//     }, 1000)
// }, 1000)

// console.log("hello");

// function colorChange(newColor, delay, doNext) {
//     setTimeout(() => {
//         document.body.style.backgroundColor = newColor;
//         if (doNext) {
//             doNext();
//         }   // equivalent to doNext && doNext();
//     }, delay)
// }

// colorChange('red', 1000, () => {
//     colorChange('orange', 1000, () => {
//         colorChange('yellow', 1000, () => {
//             colorChange('green', 1000, ()=> {
//                 colorChange('cyan',1000, ()=> {
//                     colorChange('blue',1000, ()=> {
//                         colorChange('purple', 1000);
//                     })
//                 })
//             })
//         })
//     })
// })

// console.log('hello');

// Promise method
// const colorChange = (newColor, delay) => {
//     return new Promise((resolve, reject) => {
//         setTimeout(()=>{
//             document.body.style.backgroundColor = newColor;
//             resolve();
//         },delay)
//     })
// }

// colorChange('red',1000)
//     .then(()=>{
//         return colorChange('orange',1000)
//     })
//     .then(()=>{
//         return colorChange('yellow',1000)
//     })
//     .then(()=>{
//         return colorChange('green',1000)
//     })

//ASYNC promise
// const colorChange = (newColor, delay) => {
//     return new Promise((resolve, reject) => {
//         setTimeout(()=>{
//             document.body.style.backgroundColor = newColor;
//             resolve();
//         },delay)
//     })
// }

// const colorChange = async (newColor, delay) => {
//         setTimeout(()=>{
//             document.body.style.backgroundColor = newColor;
//             return;
//         },delay)
// }

// const rainbow = async() => {
//     await colorChange('red',1000);
//     await colorChange('orange',1000);
//     await colorChange('yellow',1000);
//     await colorChange('green',1000);
//     await colorChange('blue',1000);
//     await colorChange('indigo',1000);
//     await colorChange('purple',1000);
//     return "All done!";
// }

// console.log("1");
// rainbow()
//     .then ((data)=> console.log(data));
// console.log("2");

// const posts = [
//     {title: 'Post One', body: 'This is post one'},
//     {title: 'Post Two', body: 'This is post two'}
// ];

// function getPosts() {
//     setTimeout(() => { 
//         let output = '';
//         posts.forEach((post,index) => {
//             output += `<li>${post.title}</li>`;
//         });
//         document.body.innerHTML = output;
//     },1000);
// }

// function createPost(post) {
//     setTimeout(()=> {
//         posts.push(post);
//     }, 2000);
// }

// getPosts();

// createPost({title: 'Post Three', body: 'This is post three'});


// async makeTwoRequests() {
//     await fakeRequest('/page1');
// }












        // const login = async(username, password) => {
        //     if (!username || !password) throw 'Missing Credentials'
        //     if (password ==='pusuiscute') return 'Welcome'
        //     throw 'Invalid'
        // }




