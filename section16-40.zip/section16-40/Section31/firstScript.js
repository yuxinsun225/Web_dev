// for (let i = 0; i < 10; i++) {
//     console.log("HELLO FROM FIRST SCRIPT!!")
//

// names = process.argv.slice(2);

// for (let person of names) {
//     console.log(`Hello, ${person}`);
// }

const fs = require('fs');

// fs.mkdir('Dogs', { recursive: true }, (err) => {
//     console.log("in the callback")
//     if (err) throw err;
// });
// console.log('I come after');

const folderName = process.argv[2] || 'Project';
// try {
//     fs.mkdirSync(folderName);
//     fs.writeFileSync(`${folderName}/index.html`)
//     fs.writeFileSync(`${folderName}/app.js`)
//     fs.writeFileSync(`${folderName}/styles.css`)
// }
// catch (e) {
//     console.log('something went wrong!!');
//     console.log(e);
// }

try {
    fs.mkdirSync(folderName);
    fs.writeFileSync(`${folderName}/index.html`, '')
    fs.writeFileSync(`${folderName}/app.js`, '')
    fs.writeFileSync(`${folderName}/styles.css`, '')
} catch (e) {
    console.log("SOMETHING WENT WRONG!!!");
    console.log(e);
}