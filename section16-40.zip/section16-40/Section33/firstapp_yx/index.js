import express from 'express';
const app = express();

// app.use((req, res) => {
//     console.log("We got a new request!!!")
//     res.send({ color: 'red' })
// })

app.listen(8080, () => {
    console.log("listening on port 8080")
})

app.get('/r/:subreddit/:postId', (req, res) => {
    const { subreddit, postId } = req.params;
    res.send(`<h1>Viewing post ID: ${postId} on the ${subreddit} subreddit</h1>`);
})

app.get('/cats', (req, res) => {
    res.send('Meow');
})

app.get('/dogs', (req, res) => {
    res.send('Wuff');
})

app.get('/search', (req, res) => {
    console.log(Object.keys(req.query).length);
    if (!Object.keys(req.query).length) {
        res.send("if there's nothing searched, there's nothing found.")
    } else {
        const { q } = req.query;
        res.send(`hi, query is ${q}`);
    }
})

app.get('/', (req, res) => {
    res.send('this is home!');
})
