console.log("Hello")

const player1 = document.querySelector('#player1');
const player2 = document.querySelector('#player2');
const score1 = document.querySelector('#score1');
const score2 = document.querySelector('#score2');
const round = document.querySelector('#numRounds');
const rst = document.querySelector('#reset');

player1.addEventListener('click', () => {
    const nRound = parseInt(round.value);
    round.disabled=true;
    updateScore(score1,score2,player1,player2,nRound);
})

player2.addEventListener('click', () => {
    const nRound = parseInt(round.value);
    round.disabled=true;
    updateScore(score2,score1,player1,player2,nRound);
})

rst.addEventListener('click', ()=> {
    score1.innerText = 0;
    score2.innerText = 0;
    score1.classList.remove('red','green');
    score2.classList.remove('red','green');
    round.disabled = false;
    player1.disabled = false;
    player2.disabled = false;
})


function updateScore(playerScore, opponentScore, player, opponent, numRound) {
let newScore;
newScore = parseInt(playerScore.innerText) + 1;
playerScore.innerText = newScore;
if (newScore===numRound) {
    playerScore.classList.add('red');
    opponentScore.classList.add('green');
    player.disabled = true;
    opponent.disabled = true;
}
}
